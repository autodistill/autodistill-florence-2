from autodistill_florence_2.model import Florence2, Florence2Trainer

__version__ = "0.1.0"
